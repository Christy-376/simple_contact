package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.xml.transform.StringResult;

import com.example.demo.delegate.ContactDetailsDelegate;
import com.example.demo.model.ContactDetails;
import com.example.demo.vo.ContactDetailsVo;

@SpringBootTest
@SpringJUnitConfig
 class ContactDetailsControllerTest {
	ContactMangementController contactManagementl;
	
	@Mock
	ContactDetailsDelegate contactDetailsDelegate;
	
	@Test
	void createControlDetails() throws Exception{
		ContactDetails contactDetails = new ContactDetails();
		contactDetails.setName("Christeena");
		contactDetails.setAddress("sneha bhavan");
		contactDetails.setPhoneNumber("8129966080");
		contactDetails.setEmail("christeenalukose376@gamil.com");
		
		ContactDetailsVo contactDetailsVo = new ContactDetailsVo();
		contactDetailsVo.setName("Christeena");
		contactDetailsVo.setAddress("sneha bhavan");
		contactDetailsVo.setPhoneNumber("8129966080");
		contactDetailsVo.setEmail("christeenalukose376@gamil.com");
		
		assertEquals(contactDetails.getName(), contactDetailsVo.getName());
		assertEquals(contactDetails.getAddress(), contactDetailsVo.getAddress());
		assertEquals(contactDetails.getPhoneNumber(), contactDetailsVo.getPhoneNumber());
		assertEquals(contactDetails.getEmail(), contactDetailsVo.getEmail());
	}
	

}
