package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.delegate.ContactDetailsDelegate;
import com.example.demo.model.ContactDetails;
import com.example.demo.vo.ContactDetailsVo;

@RestController
public class ContactMangementController {

	@Autowired
	ContactDetailsDelegate contactDetailsDelegate;

	@RequestMapping("/contact")
	@PostMapping("/contactDetails")
	public ContactDetailsVo createControlDetails(@RequestBody ContactDetails contactDetails) throws Exception {
		ContactDetailsVo contactDetailsResponse = null;
		if (contactDetails.getName() != null && contactDetails.getPhoneNumber()!=null ) {
			contactDetailsResponse = contactDetailsDelegate.createControlDetails(contactDetails);
        }else {
        	throw new Exception("Name and phone number are mandatory");
        }
		return contactDetailsResponse;
	}

	@GetMapping("/contactDetails")
	public List<ContactDetails> getControlDetails() {
		List<ContactDetails> contactDetailsResponse = contactDetailsDelegate.getControlDetails();
		return contactDetailsResponse;
	}

	@DeleteMapping("/contactDetails/{id}")
	public String deleteContactDetails(@PathVariable long id) {
		String deleteResponse = contactDetailsDelegate.deleteContactDetails(id);
		return deleteResponse;

	}

}
