package com.example.demo.delegateImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.delegate.ContactDetailsDelegate;
import com.example.demo.model.ContactDetails;
import com.example.demo.service.ContactDetailsService;
import com.example.demo.vo.ContactDetailsVo;
@Component
public class contactDetailsDelegateImpl implements ContactDetailsDelegate {
	@Autowired
	ContactDetailsService contactDetailsService;

	@Override
	public ContactDetailsVo createControlDetails(ContactDetails contactDetails) throws Exception{
		return contactDetailsService.createControlDetails(contactDetails) ;
	}

	@Override
	public List<ContactDetails> getControlDetails() {
		return contactDetailsService.getControlDetails();
	}

	@Override
	public String deleteContactDetails(long id) {
		
	 return contactDetailsService.deleteContactDetails(id);
	}

}
