package com.example.demo.delegate;

import java.util.List;

import com.example.demo.model.ContactDetails;
import com.example.demo.vo.ContactDetailsVo;

public interface ContactDetailsDelegate {

    ContactDetailsVo createControlDetails(ContactDetails contactDetails)throws Exception;

	List<ContactDetails> getControlDetails();

	String deleteContactDetails(long id);

}
