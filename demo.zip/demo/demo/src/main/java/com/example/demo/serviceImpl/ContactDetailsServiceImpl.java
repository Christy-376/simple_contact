package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.ContactDetails;
import com.example.demo.repository.ContactRepository;
import com.example.demo.service.ContactDetailsService;
import com.example.demo.vo.ContactDetailsVo;

public class ContactDetailsServiceImpl implements ContactDetailsService{
	@Autowired
	ContactRepository contactRepository;

	@Override
	public ContactDetailsVo createControlDetails(ContactDetails contactDetails)throws Exception {
		
		ContactDetails contactDetailreq= new ContactDetails();
		contactDetailreq.setName(contactDetails.getName());
		contactDetailreq.setAddress(contactDetails.getAddress());
		contactDetailreq.setPhoneNumber(contactDetails.getPhoneNumber());
		contactDetailreq.setEmail(contactDetails.getEmail());
		ContactDetails contact =contactRepository.saveAndFlush(contactDetailreq);
		ContactDetailsVo contactDetailsResponse = new ContactDetailsVo();
		contactDetailsResponse.setName(contact.getName());
		contactDetailsResponse.setAddress(contact.getAddress());
		contactDetailsResponse.setPhoneNumber(contact.getPhoneNumber());
		contactDetailsResponse.setEmail(contact.getEmail());
		return contactDetailsResponse;
	}

	@Override
	public List<ContactDetails> getControlDetails() {
		List<ContactDetails> contact =contactRepository.findAll();
		return contact;
	}

	@Override
	public String deleteContactDetails(long id) {
		String delete = "success";
		 contactRepository.deleteById(id);
		return delete;
	}


}
